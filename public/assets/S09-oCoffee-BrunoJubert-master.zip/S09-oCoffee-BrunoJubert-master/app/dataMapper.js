const client = require('./dataBase.js')

const dataMapper = { 

    getAllCoffee: async () => {
        const sqlQuery = "SELECT * FROM ocoffee"
        const result = await client.query(sqlQuery)
        return result.rows
    },

    getNewCoffee: async () => { 
        const sqlQuery = "SELECT * FROM ocoffee ORDER BY id DESC LIMIT 3"
        const result = await client.query(sqlQuery)
        return result.rows
    },

    getDetails: async (productId) => { 
        const query = {
            text: `SELECT * FROM ocoffee WHERE id=$1`,
            values: [productId]
        };
        const result = await client.query(query);
        return result.rows[0];
    }
}

module.exports = dataMapper;
