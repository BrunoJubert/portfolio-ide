// 1. require le module
const pg = require('pg');
require("dotenv").config()

// 2. Créer un client
const client = new pg.Client(process.env.DB_URL);

// 3. Connecter le client
client.connect();

// 4. Exporter le client connecté
module.exports = client;