const dataMapper = require("../dataMapper.js")


const mainController = {
  //afficher la home page
  homePage: async (req, res, next) => {
    
    try{
      const coffeeList = await dataMapper.getNewCoffee()
      console.log(coffeeList)
      res.render('index', {  
            title: 'Accueil', 
            coffeeList 
          });
    } catch(err) {
      res.status(500).send(err)
    }
    
  },
  // // afficher la page du catalogue avec tous les produits
  // catalogPage: (req, res, next) => {
  //   res.render('catalogue', {  title: 'Catalogue' });
    
  // },


  catalogPage: async (req, res, next) => {
    
    try{
      const coffeeList = await dataMapper.getAllCoffee()
      res.render('catalogue', {  
            title: 'Catalogue', 
            coffeeList 
          });
    } catch(err) {
      res.status(500).send(err)
    }
    
  },

  productsPage: async (req, res, next) => {
    const productId = req.params.id;  
    try{
      const coffeeDetails = await dataMapper.getDetails(productId);
      console.log(coffeeDetails);
      res.render('products', {  
            title: 'Détails', 
            coffeeDetails
          });
    } catch(err) {
      res.status(500).send(err)
    }
    
  },


  // afficher la page d'un produit (sur une route paramétrée)
  // productPage: (req, res, next) => {
   
  //    console.log(`[MainController] productPage`);
  //   res.render('products', {  title: 'Produit' });
  // },
  // afficher les infos de la boutique physique (adresse, téléphone, etc)
  shopPage: (req, res, next) => {
    console.log(`[MainController] shopPage`);
    res.render('shop', {  title: 'Boutique' });
    
  }
};

module.exports = mainController;


// homePage: (req, res, next) => {
//   console.log(`[MainController] homePage`);
//   res.render('index', {  
//     title: 'Accueil',  
//   });
  
// },
