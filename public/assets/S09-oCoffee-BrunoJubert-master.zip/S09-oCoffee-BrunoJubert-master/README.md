# O'Coffee

## Information du projet

[Le projet](./docs/demande-client/)

## Remarques pédagogiques et rendus

[Recommandations](./docs/recommandations/)
