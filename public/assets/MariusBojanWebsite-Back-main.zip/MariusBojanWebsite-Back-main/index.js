require("dotenv").config();

const express = require("express");
const cors = require("cors");
const sequelize = require("./sequelize/sequelize");
const userRoutes = require("./routes/userRoutes");
const adminRoutes = require("./routes/adminRoutes");

const app = express();
const port = process.env.PORT || 3000;

app.use(
  cors({
    origin: "http://localhost:4200",
    methods: ["GET", "POST", "PUT", "DELETE"],
    allowedHeaders: ["Content-Type", "Authorization"],
  })
);

app.use(express.json());
app.use("/api/users", userRoutes);
app.use("/api/admin", adminRoutes);

// Ajout d'un log pour afficher les routes enregistrées
console.log(
  "Routes enregistrées :",
  app._router.stack.filter((r) => r.route).map((r) => r.route.path)
);

sequelize
  .sync()
  .then(() => console.log("Database & tables created!"))
  .catch((error) => console.error("Error creating database tables:", error));

app.listen(port, () =>
  console.log(`Server is running on http://localhost:${port}`)
);
