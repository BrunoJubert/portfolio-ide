// middleware/adminMiddleware.js
const jwt = require("jsonwebtoken");

const adminMiddleware = (req, res, next) => {
  const token = req.headers["authorization"]?.split(" ")[1]; // Obtenir le token à partir des en-têtes

  if (!token) {
    return res.status(403).json({ error: "Token is required" });
  }

  jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
    if (err) {
      return res.status(401).json({ error: "Invalid token" });
    }

    // Vérifiez si l'utilisateur a le rôle admin
    if (decoded.role !== "admin") {
      return res
        .status(403)
        .json({ error: "Accès refusé. Vous devez être administrateur." });
    }

    req.user = decoded; // Stocker les informations décodées dans la requête
    next(); // Passer au middleware suivant ou à la route
  });
};

module.exports = adminMiddleware;
