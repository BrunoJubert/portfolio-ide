const express = require("express");
const router = express.Router();
const adminMiddleware = require("../middleware/adminMiddleware"); // Middleware pour vérifier le rôle admin
const userController = require("../controllers/userController");

// Route pour obtenir tous les utilisateurs (accessible uniquement par l'admin)
router.get("/users", adminMiddleware, userController.getAllUsers);

// Route pour obtenir un utilisateur par ID (accessible uniquement par l'admin)
router.get("/users/:id", adminMiddleware, userController.getUserById);

// Route pour mettre à jour un utilisateur par ID (accessible uniquement par l'admin)
router.put("/users/:id", adminMiddleware, userController.updateUser);

// Route pour supprimer un utilisateur par ID (accessible uniquement par l'admin)
router.delete("/users/:id", adminMiddleware, userController.deleteUser);


module.exports = router;
