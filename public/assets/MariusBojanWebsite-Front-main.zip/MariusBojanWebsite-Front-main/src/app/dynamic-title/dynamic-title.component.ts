import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dynamic-title',
  templateUrl: './dynamic-title.component.html',
  styleUrls: ['./dynamic-title.component.scss']
})
export class DynamicTitleComponent implements OnInit {
  phrases: string[] = [
    "vibrer ensemble",
    "des émotions fortes",
    "un swing endiablé",
    "des belles mélodies",
    "des moments forts",
    "du plaisir à partager",
  ];
  currentPhrase: string = '';
  displayedPhrase: string = '';
  currentIndex: number = 0;
  letterIndex: number = 0;
  typingInterval: any;
  cursorVisible: boolean = true; // État du curseur
  cursorInterval: any; // Intervalle pour le curseur

  ngOnInit() {
    this.startTyping();
    setInterval(() => {
      this.changeTitle();
    }, 6000); // Change la phrase toutes les 6 secondes
  }

  changeTitle() {
    clearInterval(this.typingInterval); // Arrêter l'animation précédente
    clearInterval(this.cursorInterval); // Arrêter le curseur précédent
    this.currentIndex = (this.currentIndex + 1) % this.phrases.length;
    this.displayedPhrase = ''; // Réinitialiser l'affichage
    this.letterIndex = 0; // Réinitialiser l'index des lettres
    this.startTyping(); // Démarrer l'animation de la nouvelle phrase
    this.startCursor(); // Démarrer l'animation du curseur
  }

  startTyping() {
    const phraseToType = this.phrases[this.currentIndex];
    
    this.typingInterval = setInterval(() => {
      if (this.letterIndex < phraseToType.length) {
        this.displayedPhrase += phraseToType[this.letterIndex]; // Ajouter la lettre en cours
        this.letterIndex++;
      } else {
        clearInterval(this.typingInterval); // Arrêter l'animation lorsque la phrase est complète
      }
    }, 100); // Ajustez la vitesse ici (100 ms par lettre)
  }

  startCursor() {
    this.cursorVisible = true; // Rendre le curseur visible au début
    this.cursorInterval = setInterval(() => {
      this.cursorVisible = !this.cursorVisible; // Alterner la visibilité du curseur
    }, 450); // Clignote toutes les 500 ms
  }

  ngOnDestroy() {
    clearInterval(this.typingInterval);
    clearInterval(this.cursorInterval);
  }
}
