import { Component, OnInit } from '@angular/core';
import { ProjectService, Project } from '../project.service';

@Component({
  selector: 'app-projects',
  templateUrl: './projects.component.html',
  styleUrls: ['./projects.component.scss'],
})
export class ProjectsComponent implements OnInit {
  projects: Project[] = [];

  constructor(private projectService: ProjectService) {}

  ngOnInit() {
    this.loadProjects();
  }

  loadProjects() {
    this.projects = this.projectService.getProjects();
  }

  getImageUrl(image: string | undefined): string {
    return image || 'assets/images/default-project-image.jpg'; // Assurez-vous que ce chemin est correct.
  }
}
