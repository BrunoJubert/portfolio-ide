import { Component, OnInit } from '@angular/core';
import { ConcertService, Concert } from '../concert.service';

@Component({
  selector: 'app-concerts',
  templateUrl: './concerts.component.html',
  styleUrls: ['./concerts.component.scss'],
})
export class ConcertsComponent implements OnInit {
  concerts: Concert[] = []; // Liste des concerts à afficher

  constructor(private concertService: ConcertService) {}

  ngOnInit() {
    this.concerts = this.concertService.getConcerts(); // Récupérer la liste des concerts lors de l'initialisation
  }

  getImageUrl(photo: any): string {
    return photo ? photo : ''; // Remplacez par une image par défaut si nécessaire
  }

  formatDate(dateTime: string): string {
    const date = new Date(dateTime);
    const day = date.getDate();
    const monthNames = [
      'Janvier',
      'Février',
      'Mars',
      'Avril',
      'Mai',
      'Juin',
      'Juillet',
      'Août',
      'Septembre',
      'Octobre',
      'Novembre',
      'Décembre',
    ];

    return `${day} ${monthNames[date.getMonth()]} ${date.getFullYear()}`;
  }

  formatTime(dateTime: string): string {
    const date = new Date(dateTime);

    return date.toLocaleTimeString('fr-FR', {
      hour: '2-digit',
      minute: '2-digit',
    });
  }
}
