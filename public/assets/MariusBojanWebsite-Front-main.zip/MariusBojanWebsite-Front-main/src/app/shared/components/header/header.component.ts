import { Component, OnInit, OnDestroy, HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from './../../../auth.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit, OnDestroy {
  isLoggedIn = false; // État de connexion de l'utilisateur
  isAdminLogged = false; // Vérifie si l'utilisateur est admin
  isNavOpen = false; // État du menu de navigation
  visible = false; // Pour afficher/masquer la modal de connexion
  username = ''; // Identifiant pour la connexion
  password = ''; // Mot de passe pour la connexion
  newUsername = ''; // Nom d'utilisateur pour l'inscription
  newEmail = ''; // Email pour l'inscription
  newPassword = ''; // Mot de passe pour l'inscription
  confirmPassword = ''; // Confirmation du mot de passe pour l'inscription
  isRegistering = false; // État pour savoir si on est en mode inscription
  showPassword = false; // Pour afficher ou masquer le mot de passe
  showConfirmPassword = false; // Pour afficher ou masquer la confirmation du mot de passe

  private authSubscription: Subscription = new Subscription();

  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit() {
    this.authSubscription = this.authService
      .isAuthenticated()
      .subscribe((isAuthenticated: boolean) => {
        this.isLoggedIn = isAuthenticated;
        console.log('État de connexion:', this.isLoggedIn);
        if (this.isLoggedIn) {
          this.checkUserRole();
        }
      });
  }

  ngOnDestroy() {
    if (this.authSubscription) {
      this.authSubscription.unsubscribe();
    }
  }

  checkUserRole() {
    this.authService.getUserRole().subscribe((role: string | null) => {
      this.isAdminLogged = role === 'admin';
      console.log('Rôle récupéré:', role);
    });
  }

  toggleNav() {
    this.isNavOpen = !this.isNavOpen;
  }

  @HostListener('document:click', ['$event'])
  handleClick(event: MouseEvent) {
    const target = event.target as HTMLElement;
    const nav = document.querySelector('.nav') as HTMLElement;
    const burgerButton = document.querySelector('.burger') as HTMLElement;

    if (
      this.isNavOpen &&
      !nav.contains(target) &&
      !burgerButton.contains(target)
    ) {
      this.isNavOpen = false;
    }
  }

  showLoginModal() {
    this.visible = true;
    this.isNavOpen = false;
    this.isRegistering = false;
  }

  closeDialog() {
    this.visible = false;
    this.resetFields();
  }

  resetFields() {
    this.username = '';
    this.password = '';
    this.newUsername = '';
    this.newEmail = '';
    this.newPassword = '';
    this.confirmPassword = '';
  }

  login() {
    const loginData = { username: this.username, password: this.password };

    console.log('Tentative de connexion avec', loginData);

    this.authService.login(loginData).subscribe(
      (response) => {
        console.log('Connexion réussie', response);
        localStorage.setItem('token', response.token);

        const payload = JSON.parse(atob(response.token.split('.')[1]));
        const isAdmin = payload.role === 'admin';

        this.authService.updateUserRole(payload.role);

        this.isLoggedIn = true;
        this.isAdminLogged = isAdmin;
        this.closeDialog();

        if (isAdmin) {
          console.log('Administrateur connecté, redirection vers le dashboard');
          this.router.navigate(['/dashboard']);
        } else {
          console.log('Utilisateur normal connecté');
          this.router.navigate(['/']);
        }

        // Forcer la mise à jour de l'état d'authentification
        this.authService.refreshAuthState();
      },
      (error) => {
        console.error('Erreur lors de la connexion', error);
        alert('Identifiants incorrects.');
      }
    );
  }

  register() {
    console.log("Tentative d'inscription avec", this.newUsername);

    if (this.newPassword !== this.confirmPassword) {
      alert('Les mots de passe ne correspondent pas.');
      return;
    }

    const userData = {
      username: this.newUsername,
      email: this.newEmail,
      password: this.newPassword,
    };

    this.authService
      .register(userData.username, userData.email, userData.password)
      .subscribe(
        (response) => {
          console.log('Inscription réussie', response);
          alert('Inscription réussie !');
          this.closeDialog();
        },
        (error) => {
          console.error("Erreur lors de l'inscription", error);
          alert("Erreur lors de l'inscription.");
        }
      );
  }

  logout() {
    this.authService.logout();
    console.log('Déconnexion réussie');
    this.router.navigate(['/']);
  }

  navigateHome() {
    this.router.navigate(['/']);
  }

  navigateToEvents() {
    this.router.navigate(['/events']);
  }

  navigateToProjects() {
    this.router.navigate(['/projects']);
  }

  navigateToContact() {
    this.router.navigate(['/contact']);
  }

  navigateToDashboard() {
    console.log(
      "Tentative d'accès au dashboard, isAdminLogged:",
      this.isAdminLogged
    ); // Log pour déboguer
    if (this.isAdminLogged) {
      console.log('Accès au dashboard autorisé');
      this.router.navigate(['/dashboard']);
    } else {
      alert(
        'Accès refusé : vous devez être administrateur pour accéder au tableau de bord.'
      );
    }
  }

  toggleRegistration() {
    this.isRegistering = !this.isRegistering;

    if (this.isRegistering) {
      this.resetFields();
    } else {
      this.newUsername = '';
      this.newEmail = '';
      this.newPassword = '';
      this.confirmPassword = '';
    }
  }
}
