import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

// Imports PrimeNG
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { CardModule } from 'primeng/card';
import { CarouselModule } from 'primeng/carousel';
import { DialogModule } from 'primeng/dialog'; // Ajout du DialogModule

import { HeaderComponent } from './components/header/header.component';

@NgModule({
  declarations: [HeaderComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    // Modules PrimeNG
    ButtonModule,
    InputTextModule,
    CardModule,
    CarouselModule,
    DialogModule, // Ajout du DialogModule aux imports
  ],
  exports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ButtonModule,
    InputTextModule,
    CardModule,
    CarouselModule,
    DialogModule, // Ajout du DialogModule aux exports
    HeaderComponent,
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA], // Ajout du CUSTOM_ELEMENTS_SCHEMA
})
export class SharedModule {}
