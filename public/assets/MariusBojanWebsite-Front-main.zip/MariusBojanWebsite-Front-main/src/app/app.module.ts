import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SharedModule } from './shared/shared.module';
import { HomeComponent } from './home/home.component';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { MatNativeDateModule } from '@angular/material/core';
import { provideHttpClient } from '@angular/common/http';

// Composants
import { DynamicTitleComponent } from './dynamic-title/dynamic-title.component';
import { DashboardComponent } from './dashboard/dashboard.component';

// Modules PrimeNG
import { CarouselModule } from 'primeng/carousel';
import { ButtonModule } from 'primeng/button';
import { MenuModule } from 'primeng/menu';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { ConcertsComponent } from './concerts/concerts.component';
import { ProjectsComponent } from './projets/projects.component';
import { ContactComponent } from './contact/contact.component';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    DynamicTitleComponent,
    DashboardComponent,
    ConcertsComponent,
    ProjectsComponent,
    ContactComponent,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule, // Nécessaire pour les animations PrimeNG
    FormsModule, // Nécessaire pour ngModel
    AppRoutingModule,
    SharedModule,
    MatDatepickerModule,
    MatInputModule,
    MatNativeDateModule,
    CarouselModule,
    ButtonModule,
    MenuModule,
    DialogModule,
    InputTextModule,
  ],
  providers: [provideAnimationsAsync('noop'),
    provideHttpClient(),
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
