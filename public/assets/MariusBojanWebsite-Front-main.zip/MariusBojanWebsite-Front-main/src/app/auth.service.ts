import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private isAuthenticatedSubject = new BehaviorSubject<boolean>(
    this.hasToken()
  );
  private userRoleSubject = new BehaviorSubject<string | null>(null); // Pour stocker le rôle de l'utilisateur
  private apiUrl = 'http://localhost:3000/api/users'; // URL de votre API

  constructor(private http: HttpClient) {
    this.isAuthenticatedSubject.next(this.hasToken());
  }

  private hasToken(): boolean {
    return !!localStorage.getItem('token');
  }

  login(loginData: { username: string; password: string }): Observable<any> {
    return this.http.post(`${this.apiUrl}/login`, loginData);
  }

  register(username: string, email: string, password: string): Observable<any> {
    const userData = { username, email, password }; // Créez un objet avec les données de l'utilisateur
    return this.http.post(`${this.apiUrl}/register`, userData); // Assurez-vous que l'API accepte cet objet
  }

  logout(): void {
    localStorage.removeItem('token');
    this.isAuthenticatedSubject.next(false);
    this.userRoleSubject.next(null); // Réinitialiser le rôle
  }

  isAuthenticated(): Observable<boolean> {
    return this.isAuthenticatedSubject.asObservable();
  }

  getUserRole(): Observable<string | null> {
    const token = localStorage.getItem('token');
    if (!token) {
      return of(null);
    }
    const payload = JSON.parse(atob(token.split('.')[1]));
    return of(payload.role);
  }

  updateUserRole(role: string): void {
    this.userRoleSubject.next(role);
  }

  isAdminLoggedIn(): boolean {
    const token = localStorage.getItem('token');
    if (token) {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.role === 'admin';
    }
    return false;
  }

  refreshAuthState() {
    this.isAuthenticatedSubject.next(this.hasToken());
    if (this.hasToken()) {
      this.getUserRole().subscribe((role) => {
        this.userRoleSubject.next(role);
      });
    }
  }
}
