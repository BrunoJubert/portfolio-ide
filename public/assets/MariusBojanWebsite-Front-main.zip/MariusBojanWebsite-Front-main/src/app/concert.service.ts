import { Injectable } from '@angular/core';

export interface Concert {
  id: number;
  venue: string;
  address: string;
  dateTime: string;
  description: string;
  photo?: string | File; // URL ou chemin de l'image
  requiresReservation?: boolean; // Indique si une réservation est requise
  reservationNumber?: string; // Numéro de réservation
  price?: number; // Prix de la réservation
}

@Injectable({
  providedIn: 'root',
})
export class ConcertService {
  private concertsKey = 'concerts';
  private concerts: Concert[] = [];

  constructor() {
    this.loadConcerts();
  }

  private loadConcerts() {
    const savedConcerts = localStorage.getItem(this.concertsKey);
    if (savedConcerts) {
      this.concerts = JSON.parse(savedConcerts);
    }
  }

  private saveConcerts() {
    localStorage.setItem(this.concertsKey, JSON.stringify(this.concerts));
  }

  addConcert(concert: Concert) {
    if (this.concerts.length >= 10) {
      alert('Vous ne pouvez pas ajouter plus de 10 concerts.');
      return;
    }

    concert.id =
      this.concerts.length > 0
        ? Math.max(...this.concerts.map((c) => c.id)) + 1
        : 1; // Assignation d'un nouvel ID
    this.concerts.push(concert);
    this.saveConcerts();
  }

  getConcerts(): Concert[] {
    return this.concerts;
  }

  updateConcert(updatedConcert: Concert) {
    const index = this.concerts.findIndex((c) => c.id === updatedConcert.id);
    if (index !== -1) {
      this.concerts[index] = updatedConcert; // Mettre à jour le concert spécifique
      this.saveConcerts();
    }
  }

  deleteConcert(id: number) {
    const index = this.concerts.findIndex((concert) => concert.id === id);
    if (index !== -1) {
      this.concerts.splice(index, 1); // Supprimer le concert spécifique
      this.saveConcerts();
    }
  }
}
