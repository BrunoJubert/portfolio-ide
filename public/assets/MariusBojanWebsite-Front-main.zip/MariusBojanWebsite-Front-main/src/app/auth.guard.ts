import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { AuthService } from './auth.service';
import { Observable, of } from 'rxjs';
import { map, take, switchMap, tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class AuthGuard implements CanActivate {
  constructor(private authService: AuthService, private router: Router) {}

  canActivate(): Observable<boolean> {
    return this.authService.isAuthenticated().pipe(
      take(1),
      switchMap((isAuthenticated: boolean) => {
        console.log('Est authentifié:', isAuthenticated);
        if (!isAuthenticated) {
          console.log(
            "Utilisateur non authentifié, redirection vers la page d'accueil"
          );
          this.router.navigate(['/']);
          return of(false);
        }
        return this.authService.getUserRole().pipe(
          map((role: string | null) => {
            console.log('Rôle récupéré:', role);
            const isAdmin = role === 'admin';
            console.log('Est admin:', isAdmin);
            if (!isAdmin) {
              console.log(
                "Utilisateur non admin, redirection vers la page d'accueil"
              );
              this.router.navigate(['/']);
              return false;
            }
            return true;
          }),
          tap((canAccess: boolean) => {
            if (canAccess) {
              console.log('Accès au dashboard autorisé');
            }
          })
        );
      })
    );
  }
}
