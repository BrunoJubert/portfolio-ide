import { Injectable } from '@angular/core';

export interface CarouselImage {
  id: number;
  imageUrl: string;
}

@Injectable({
  providedIn: 'root',
})
export class CarouselService {
  private carouselImages: CarouselImage[] = []; // Tableau vide pour stocker les images

  constructor() {
    this.loadImagesFromLocalStorage(); // Charger les images depuis le localStorage au démarrage
  }

  private loadImagesFromLocalStorage() {
    const storedImages = localStorage.getItem('carouselImages');
    if (storedImages) {
      this.carouselImages = JSON.parse(storedImages);
      console.log(
        'Images chargées depuis le localStorage:',
        this.carouselImages
      ); // Debugging
    }
  }

  private saveImagesToLocalStorage() {
    localStorage.setItem('carouselImages', JSON.stringify(this.carouselImages));
    console.log(
      'Images sauvegardées dans le localStorage:',
      this.carouselImages
    ); // Debugging
  }

  getCarouselImages(): CarouselImage[] {
    return this.carouselImages; // Retourne toutes les images du carousel
  }

  addCarouselImage(image: CarouselImage) {
    const newId =
      this.carouselImages.length > 0
        ? Math.max(...this.carouselImages.map((img) => img.id), 0) + 1
        : 1;
    image.id = newId;
    this.carouselImages.push(image); // Ajoute une nouvelle image au tableau
    this.saveImagesToLocalStorage(); // Sauvegarder les images après ajout
    console.log('Image ajoutée:', image);
  }

  updateCarouselImage(updatedImage: CarouselImage) {
    const index = this.carouselImages.findIndex(
      (img) => img.id === updatedImage.id
    );
    if (index !== -1) {
      this.carouselImages[index] = updatedImage; // Met à jour l'image existante
      this.saveImagesToLocalStorage(); // Sauvegarder après mise à jour
      console.log('Image mise à jour:', updatedImage);
    }
  }

  deleteCarouselImage(id: number) {
    this.carouselImages = this.carouselImages.filter((img) => img.id !== id); // Supprime l'image par ID
    this.saveImagesToLocalStorage(); // Sauvegarder après suppression
    console.log(`Image avec l'ID ${id} supprimée.`);
  }
}
