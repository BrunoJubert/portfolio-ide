import { Component, OnInit, AfterViewInit, OnDestroy } from '@angular/core';
import { CarouselService, CarouselImage } from '../carousel.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit, AfterViewInit, OnDestroy {
  private currentSlide = 0;
  private autoSlideInterval: any;
  carouselImages: CarouselImage[] = [];

  constructor(private carouselService: CarouselService) {}

  ngOnInit(): void {
    this.loadCarouselImages();
  }

  ngAfterViewInit(): void {
    this.showSlide(this.currentSlide);
    this.startAutoSlide();
  }

  ngOnDestroy(): void {
    this.stopAutoSlide();
  }

  loadCarouselImages(): void {
    this.carouselImages = this.carouselService.getCarouselImages();
    console.log('Images chargées:', this.carouselImages); // Pour débogage
  }

  private showSlide(index: number): void {
    this.carouselImages.forEach((image, i) => {
      const slide = document.getElementById(`slide${i}`);
      if (slide) {
        (slide as HTMLElement).style.opacity = i === index ? '1' : '0';
      }
    });
  }

  nextSlide(): void {
    this.currentSlide = (this.currentSlide + 1) % this.carouselImages.length;
    this.showSlide(this.currentSlide);
    this.resetAutoSlide();
  }

  prevSlide(): void {
    this.currentSlide =
      (this.currentSlide - 1 + this.carouselImages.length) %
      this.carouselImages.length;
    this.showSlide(this.currentSlide);
    this.resetAutoSlide();
  }

  private startAutoSlide(): void {
    this.autoSlideInterval = setInterval(() => {
      this.nextSlide();
    }, 5000);
  }

  private stopAutoSlide(): void {
    if (this.autoSlideInterval) {
      clearInterval(this.autoSlideInterval);
    }
  }

  private resetAutoSlide(): void {
    this.stopAutoSlide();
    this.startAutoSlide();
  }
}
