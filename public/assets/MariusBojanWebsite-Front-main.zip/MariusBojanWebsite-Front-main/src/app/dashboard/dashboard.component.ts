import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { ConcertService, Concert } from '../concert.service';
import { ProjectService, Project } from '../project.service';
import { CarouselService, CarouselImage } from '../carousel.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
})
export class DashboardComponent implements OnInit {
  concerts: Concert[] = [];
  projects: Project[] = [];
  carouselImages: CarouselImage[] = []; // Pour stocker les images du carousel

  concert: Concert = {
    id: 0,
    venue: '',
    address: '',
    dateTime: '',
    description: '',
    photo: undefined,
    requiresReservation: false,
    reservationNumber: '',
    price: undefined,
  };

  project: Project = {
    id: 0,
    title: '',
    description: '',
    image: undefined,
    link: '',
    imageOnly: false,
  };

  carouselImage: CarouselImage = {
    id: 0,
    imageUrl: '',
  };

  isEditing = false;
  isEditingProject = false;
  isEditingCarouselImage = false;

  isDropdownOpen = false;
  isProjectDropdownOpen = false;
  isCarouselDropdownOpen = false;

  username: string = 'Marius';

  constructor(
    private concertService: ConcertService,
    private projectService: ProjectService,
    private carouselService: CarouselService, // Injection du service Carousel
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit() {
    this.loadConcerts();
    this.loadProjects();
    this.loadCarouselImages(); // Charger les images du carousel
  }

  loadConcerts() {
    this.concerts = this.concertService.getConcerts();
    this.concerts.sort(
      (a, b) => new Date(a.dateTime).getTime() - new Date(b.dateTime).getTime()
    );
  }

  loadProjects() {
    this.projects = this.projectService.getProjects();
  }

  loadCarouselImages() {
    this.carouselImages = this.carouselService.getCarouselImages(); // Charger les images depuis le service
    console.log('Images du carousel chargées:', this.carouselImages); // Debugging
  }

  addConcert(photoInput: HTMLInputElement) {
    if (this.isEditing) {
      this.concertService.updateConcert(this.concert);
      console.log('Concert mis à jour:', this.concert); // Debugging
    } else {
      this.concertService.addConcert(this.concert);
      console.log('Nouveau concert ajouté:', this.concert); // Debugging
    }

   // Réinitialiser le formulaire et recharger les concerts
   this.resetConcertForm();
   photoInput.value = '';
   this.loadConcerts();
}

addProject(projectImageInput: HTMLInputElement) {
if (this.isEditingProject) {
     this.projectService.updateProject(this.project);
     console.log('Projet mis à jour:', this.project); // Debugging
} else {
     this.projectService.addProject(this.project);
     console.log('Nouveau projet ajouté:', this.project); // Debugging
}

// Réinitialiser le formulaire et recharger les projets
this.resetProjectForm();
projectImageInput.value = '';
this.loadProjects();
}

addCarouselImage(imageInput: HTMLInputElement) {
if (this.isEditingCarouselImage) {
     this.carouselService.updateCarouselImage(this.carouselImage);
     console.log('Image du carousel mise à jour:', this.carouselImage); // Debugging
} else {
     this.carouselService.addCarouselImage(this.carouselImage); // Ajouter une nouvelle image au carousel
     console.log('Nouvelle image ajoutée au carousel:', this.carouselImage); // Debugging
}

// Réinitialiser le formulaire et recharger les images du carousel
this.resetCarouselImageForm();
imageInput.value = '';
this.loadCarouselImages(); // Recharger les images après ajout
}

editEvent(event: Concert) {
   this.concert = { ...event };
   this.isEditing = true;
}

editProject(project: Project) {
   this.project = { ...project };
   this.isEditingProject = true;
}

editCarouselImage(image: CarouselImage) {
   this.carouselImage = { ...image };
   this.isEditingCarouselImage = true;
}

deleteEvent(id: number) {
   this.concertService.deleteConcert(id);
   console.log(`Concert avec l'ID ${id} supprimé.`); // Debugging
   this.loadConcerts();
}

deleteProject(id: number) {
   this.projectService.deleteProject(id);
   console.log(`Projet avec l'ID ${id} supprimé.`); // Debugging
   this.loadProjects();
}

deleteCarouselImage(id: number) {
   this.carouselService.deleteCarouselImage(id); // Supprimer l'image du carousel
   console.log(`Suppression de l'image avec l'ID ${id}`); // Debugging
   this.loadCarouselImages(); // Recharger les images après suppression
}

resetConcertForm() {
   // Réinitialisation du formulaire de concert
   this.concert = {
      id: 0,
      venue: '',
      address: '',
      dateTime: '',
      description: '',
      photo: undefined,
      requiresReservation: false,
      reservationNumber: '',
      price: undefined,
   };
   this.isEditing = false;

   const photoInput = document.getElementById('photo') as HTMLInputElement;
   if (photoInput) photoInput.value = '';

   const imagePreview = document.querySelector(
      '.preview-image'
   ) as HTMLImageElement;
   if (imagePreview) imagePreview.src = '';
}

resetProjectForm() {
   // Réinitialisation du formulaire de projet
   this.project = {
      id: 0,
      title: '',
      description: '',
      image: undefined,
      link: '',
      imageOnly: false,
   };
   this.isEditingProject = false;

   const projectImageInput = document.getElementById(
      'projectImage'
   ) as HTMLInputElement;
   if (projectImageInput) projectImageInput.value = '';

   const projectImagePreview = document.querySelector(
      '.preview-image'
   ) as HTMLImageElement;
   if (projectImagePreview) projectImagePreview.src = '';
}

resetCarouselImageForm() {
   // Réinitialisation du formulaire d'image du carousel
   this.carouselImage = { id: 0, imageUrl: '' };
   this.isEditingCarouselImage = false;

   const carouselImageInput = document.getElementById('carouselImage') as HTMLInputElement;
   if (carouselImageInput) carouselImageInput.value = '';

   const carouselImagePreview =
      document.querySelector('.carousel-preview-image') as HTMLImageElement;
   if (carouselImagePreview) carouselImagePreview.src = '';
}

onFileSelected(event: Event, isProject?: boolean) {
   const fileInput = event.target as HTMLInputElement;
   if (fileInput.files && fileInput.files.length > 0) {
      const file = fileInput.files[0];
      const reader = new FileReader();
      reader.onload = () => {
         if (isProject) {
            // Charger l'image pour un projet
            console.log('Chargement de l\'image pour le projet:', reader.result); // Debugging
            this.project.image = reader.result as string;
         } else {
            // Charger la photo pour un concert
            console.log('Chargement de la photo pour le concert:', reader.result); // Debugging
            this.concert.photo = reader.result as string;
         }
      };
      reader.readAsDataURL(file);
   }
}

onCarouselImageSelected(event: Event) {
   const fileInput = event.target as HTMLInputElement;
   if (fileInput.files && fileInput.files.length > 0) {
      const file = fileInput.files[0];
      const reader = new FileReader();
      reader.onload = () => {
         // Charger l'image pour le carousel
         console.log('Chargement de l\'image pour le carousel:', reader.result); // Debugging
         this.carouselImage.imageUrl = reader.result as string;
      };
      reader.readAsDataURL(file);
   }
}

toggleDropdown() {
   // Ouvrir ou fermer le dropdown des événements
   this.isDropdownOpen = !this.isDropdownOpen;
}

toggleProjectDropdown() {
   // Ouvrir ou fermer le dropdown des projets
   this.isProjectDropdownOpen = !this.isProjectDropdownOpen;
}

toggleCarouselDropdown() {
   // Ouvrir ou fermer le dropdown des images du carousel
   this.isCarouselDropdownOpen =
     !this.isCarouselDropdownOpen;
}

logout() {
   // Déconnexion de l'utilisateur et redirection vers la page d'accueil
   this.authService.logout();
   this.router.navigate(['/']);
}
}