import { NgModule, Optional, SkipSelf } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    // Ajout du HttpClientModule pour les requêtes API
    HttpClientModule
  ],
  exports: [
    // Export de HttpClientModule pour le rendre disponible dans toute l'application
    HttpClientModule
  ]
})
export class CoreModule {
  // Nouveau constructeur pour s'assurer que CoreModule n'est importé qu'une seule fois
  constructor(@Optional() @SkipSelf() parentModule: CoreModule) {
    if (parentModule) {
      throw new Error('CoreModule is already loaded. Import it in the AppModule only.');
    }
  }
}
