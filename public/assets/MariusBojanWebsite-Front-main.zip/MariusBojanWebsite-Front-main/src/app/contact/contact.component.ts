import { Component } from '@angular/core';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.scss'],
})
export class ContactComponent {
  contactModel = {
    name: '',
    email: '',
    subject: '',
    message: '',
  };

  onSubmit() {

    this.contactModel = {
      name: '',
      email: '',
      subject: '',
      message: '',
    };
  }
}
