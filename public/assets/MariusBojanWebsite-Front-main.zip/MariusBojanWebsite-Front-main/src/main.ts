import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app/app.module';
import { environment } from './environments/environement';

if (environment.production) {
  // Ici, vous pouvez ajouter du code spécifique à la production si nécessaire
  // Par exemple, désactiver les logs de débogage
  console.log = () => {};
}

platformBrowserDynamic()
  .bootstrapModule(AppModule, {
    ngZoneEventCoalescing: true,
  })
  .catch((err) => console.error(err));
