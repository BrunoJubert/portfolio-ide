export const environment = {
  production: false,
  adminUsername: 'Marius',
  adminPassword: 'BireliIsMyHero2024',
};
